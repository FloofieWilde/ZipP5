#pragma once

using namespace System;
namespace NS_composants
{
	public ref class CLimages
	{
	public:
		System::Drawing acquisitionImage(String^);
	};
}